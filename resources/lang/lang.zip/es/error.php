<?php 

return [
    'back' => 'back',
    'back_to_home' => 'back_to_home',
    'page' => [
        'not_found' => 'page.not_found',
    ],
    'permission' => 'permission',
    'store_disabled' => 'store_disabled',
];