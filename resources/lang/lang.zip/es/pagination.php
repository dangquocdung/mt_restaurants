<?php 

return [
    'previous' => '',
    'next' => '',
];