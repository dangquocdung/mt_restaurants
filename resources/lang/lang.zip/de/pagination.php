<?php 

return [
    'next' => 'Nächster "',
    'previous' => '" Bisherige',
];