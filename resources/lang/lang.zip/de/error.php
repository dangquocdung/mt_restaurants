<?php 

return [
    'back' => 'Geh zurück',
    'back_to_home' => 'Zurück zum Profil',
    'page' => [
        'not_found' => 'Seite nicht gefunden',
    ],
    'permission' => 'Benutzer hat keine Erlaubnis',
    'store_disabled' => 'store_disabled',
];