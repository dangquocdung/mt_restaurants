<?php 

return [
    'next' => 'Suivant »',
    'previous' => '« Précédent',
];