<?php 

return [
    'back' => 'Revenir en arrière',
    'back_to_home' => 'Aller à la page profile',
    'page' => [
        'not_found' => 'Page introuvable',
    ],
    'permission' => 'Vous n\'avez pas l\'autorisation pour accéder à cette page',
    'store_disabled' => 'store_disabled',
];